//
//  ViewController.swift
//  Kitty Katch
//
//  Created by mac on 11/04/2019.
//  Copyright © 2019 Adanna Achonu. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
   
    @IBOutlet weak var katchLabel: UILabel!
   
    
    
    let kittyArray = ["kitty1", "kitty2", "kitty3", "kitty4", "kitty5", "kitty6"]
    
    var randomKittyIndex1: Int = 0
    var randomKittyIndex2: Int = 0

    @IBOutlet weak var kittyImageView1: UIImageView!
    @IBOutlet weak var kittyImageView2: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        updateKittyImages()
        
    }

    @IBAction func KatchMeButtonPressed(_ sender: UIButton) {
        
        // does something when the Katch Me button is pressed
        updateKittyImages()
 
        }
        
        func updateKittyImages() {
            
            randomKittyIndex1 = Int.random(in: 0...5)
            randomKittyIndex2 = Int.random(in: 0...5)
            
            
            kittyImageView1.image = UIImage.init(named: kittyArray[randomKittyIndex1])
            
            kittyImageView2.image = UIImage.init(named: kittyArray[randomKittyIndex2])
            
            katchLabel.isHidden = true
            
            if(randomKittyIndex1 == randomKittyIndex2) {
                
                katchLabel.isHidden = false;
            }
            
        }
       
    }
    
    
    
   
    


